#include<bits/stdc++.h>
#define int long long
using namespace std;
vector<int> v[100005],w[100005],d[100005];
int n,m,f[100005],mxd=0,inq[100005];
int spfa(int x,int t){
    memset(f,0x3f,sizeof(f));
    memset(inq,0,sizeof(inq));
    queue<int> q;q.push(x);f[x]=t;inq[x]=1;
    if(x==n) return f[n];
    while(!q.empty()){
        int st=q.front();q.pop();inq[st]=0;
        for(int i=0;i<v[st].size();i++){
            if(f[st]+w[st][i]+d[st][i]/(f[st]+1)<f[v[st][i]]){
                f[v[st][i]]=f[st]+w[st][i]+d[st][i]/(f[st]+1);
                if(!inq[v[st][i]]) q.push(v[st][i]),inq[v[st][i]]=1;
            }
        }
    }
    return f[n];
}
signed main(){
    freopen("road.in","r",stdin);
    freopen("road.out","w",stdout);
    ios::sync_with_stdio(0);
    cin>>n>>m;
    for(int i=0;i<m;i++){
        int a,b,c,D;cin>>a>>b>>c>>D;
        v[a].push_back(b);v[b].push_back(a);
        w[a].push_back(c);w[b].push_back(c);
        d[a].push_back(D);d[b].push_back(D);
        mxd=max(mxd,D);
    }
    int ans=1e15;
    for(int i=0;i<v[1].size();i++){
        int tmp=sqrt(d[1][i]);
        if(d[1][i]==0) ans=min(ans,spfa(v[1][i],w[1][i])); 
        else ans=min(ans,spfa(v[1][i],w[1][i]+min(d[1][i]/tmp+tmp-1,d[1][i]/(tmp+1)+tmp)));
    }
    cout<<ans;
    return 0;
}