#include<bits/stdc++.h>
using namespace std;
int main(){
    freopen("turn.in","r",stdin);
    freopen("turn.out","w",stdout);
    int n,m;
    cin>>n>>m;
    while(m--) cout<<"diff\n";
    return 0;
}