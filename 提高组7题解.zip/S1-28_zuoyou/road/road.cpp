//road
#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 1e5 + 10;
int n, m, c[N], d[N];
ll dis[N];
vector<int> g[N];
map<pair<ll, int>, int> mp;

int main(){
	freopen("road.in", "r", stdin);
	freopen("road.out", "w", stdout);
	scanf("%d", &n);
	scanf("%d", &m);
	for(int i = 1; i <= m; ++ i){
		int a, b;
		scanf("%d", &a);
		scanf("%d", &b);
		scanf("%d", &c[i]);
		scanf("%d", &d[i]);
		g[a].push_back(b);
		g[b].push_back(a);
		mp[make_pair(a, b)] = i;
		mp[make_pair(b, a)] = i;
	}
	memset(dis, 0x3f, sizeof(dis));
	dis[1] = 0;
	priority_queue<pair<int, int> > q;
	q.push(make_pair(0, 1));
	while(!q.empty()){
		pair<ll, int> p = q.top();
		q.pop();
		int x = p.second;
		for(int i = 0; i < g[x].size(); ++ i){
			int y = g[x][i], id = mp[make_pair(x, y)];
			ll mn = dis[x] + c[id] + d[id] / (dis[x] + 1);
			ll s = sqrt(d[id]);
			if(dis[x] < s){
				for(ll j = max(dis[x] + 1, s - 5); j <= s + 5; ++ j){
					mn = min(mn, j + c[id] + d[id] / (j + 1));
				}
			}
			if(dis[y] > mn){
				dis[y] = mn;
				q.push(make_pair(-dis[y], y));
			}
		}
	} 
	printf("%lld\n", dis[n] == 0x3f3f3f3f3f3f3f3f ? -1 : dis[n]);
	return 0;
} 
