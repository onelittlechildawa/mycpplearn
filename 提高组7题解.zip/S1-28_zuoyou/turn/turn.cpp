//turn
//bitset O(n^3/8+m)
//O(n^2+mn) 
#include <bits/stdc++.h>
using namespace std;

const int N = 1e3 + 10, M = 2e5 + 10;
pair<int, int> e[M];
vector<int> g[N];
int n, m, ans[M], vis[N];

bool rch(int x, int to, int fr){
	bool flg = false;
	vis[x] = 1;
	for(int i = 0; i < g[x].size(); ++ i){
		int y = g[x][i];
		if(vis[y]) continue;
		if(y == to && x != fr){
			return 1;
		}
		if(x != fr || y != to){
			flg |= rch(y, to, fr);		
		}
	}
	return flg;
}

int main(){
	freopen("turn.in", "r", stdin);
	freopen("turn.out", "w", stdout);
	scanf("%d", &n);
	scanf("%d", &m);
	for(int i = 1; i <= m; ++ i){
		int x, y;
		scanf("%d", &x);
		scanf("%d", &y);
		g[x].push_back(y);
		e[i] = make_pair(x, y);
	}
	for(int i = 1; i <= m; ++ i){
		int x = e[i].first, y = e[i].second;
		if(rch(x, y, x)){
			ans[i] ^= 1;
		}
		memset(vis, 0, sizeof(vis));
		if(rch(y, x, y)){
			ans[i] ^= 1;
		}
		memset(vis, 0, sizeof(vis));
	}
	for(int i = 1; i <= m; ++ i){
		puts(ans[i] ? "diff" : "same");
	}
	return 0;
}
