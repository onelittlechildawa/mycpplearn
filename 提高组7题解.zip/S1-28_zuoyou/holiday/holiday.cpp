//holiday
#include <bits/stdc++.h>
using namespace std;

int d, k, t;
int f[]

int main(){
	scanf("%d", &d);
	scanf("%d", &k);
	scanf("%d", &t);
	
	
}
