//table
#include <bits/stdc++.h>
using namespace std;

int n, m;

int main(){
	freopen("table.out", "w", stdout);
	puts("111111");
}
