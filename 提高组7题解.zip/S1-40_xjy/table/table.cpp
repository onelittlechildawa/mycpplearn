#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN=1e9,MOD=998244353,SIZE=1e6,PNUM=78498;
const int Limit=31623;

struct HashTable
{
	struct msg {int KEY,data;};vector<msg> buc[Limit+5];
	inline int Ask(int x)
	{
		int y=x%Limit;
		for(int i=0;i<buc[y].size();i++) if(buc[y][i].KEY==x) return buc[y][i].data;
		return -1;
	}
	inline void Insert(int x,int v) {buc[x%Limit].push_back(msg{x,v});}
}pow2,powm,dp;

inline int POW(int a,int b)
{
	int A=a,B=b,res;
	if(B==2) res=pow2.Ask(A); else res=powm.Ask(A);
	if(res>=0) return res;
	
	res=1;
	for(;b;b>>=1,a=1ll*a*a%MOD)
		if(b&1) res=1ll*res*a%MOD;
		
	if(B==2) pow2.Insert(A,res); else powm.Insert(A,res);
	return res;
}

int n,ans;ll m;

int mu[SIZE+5];
int Prime[PNUM+5],pnum;
bool V[SIZE+5];
inline void pret()
{
	mu[1]=1;
	for(int i=2;i<=SIZE;i++)
	{
		if(!V[i]) Prime[++pnum]=i,mu[i]=-1;
		for(int j=1;j<=pnum;j++)
		{
			if(i*Prime[j]>SIZE) break;
			V[i*Prime[j]]=1;
			if(i%Prime[j]) mu[i*Prime[j]]=-mu[i];
			else {mu[i*Prime[j]]=0;break;}
		}
	}
	for(int i=2;i<=SIZE;i++)
	{
		if(mu[i]<0) mu[i]+=MOD;
		mu[i]+=mu[i-1];
		if(mu[i]>=MOD) mu[i]-=MOD;
	}
	//printf("%d\n",pnum);
}

int SumMU(int x)
{
	if(x<=SIZE) return mu[x];
	int res=dp.Ask(x);
	if(res>=0) return res;
	
	res=1;
	for(int L=2,R;L<=x;L=R+1)
	{
		R=x/(x/L);
		res-=1ll*(R-L+1)*SumMU(x/L)%MOD;
		if(res<0) res+=MOD;
	}
	dp.Insert(x,res);
	return res;
}
inline int GetSum(int L,int R)
{
	int res=SumMU(R)-SumMU(L-1);
	if(res<0) res+=MOD;
	return res;
}

inline int Solve(int x,int y)//�Ͻ�ʹ���
{
	int res=0;
	for(int L=1,R;L<=x;L=R+1)
	{
		R=x/(x/L);
		res+=1ll*GetSum(L,R)*POW(x/L,y)%MOD;
		if(res>=MOD) res-=MOD;
	}
	return res;
}

int main()
{
	freopen("table.in","r",stdin);
	freopen("table.out","w",stdout);
	pret();
	scanf("%d %lld",&n,&m);
	m%=MOD-1;
	for(int L=1,R;L<=n;L=R+1)
	{
		R=n/(n/L);
		//n/d = n/L
		ans+=1ll*(R-L+1)*Solve(n/L,2)%MOD*Solve(n/L,m)%MOD;
		if(ans>=MOD) ans-=MOD;
	}
	printf("%d\n",ans);
	return 0;
}
