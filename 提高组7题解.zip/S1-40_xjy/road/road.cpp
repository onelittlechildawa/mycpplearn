#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const int MAXN=1e5;
const ll INF=1e15;

int n,m;
struct DE {int nxt,c,d;};vector<DE> G[MAXN+5];

inline bool LessThanSqrt(ll a,int b)
{
	if(a>31623) return 0;
	return a*a<=b;
}

ll Dist[MAXN+5];bool V[MAXN+5];
priority_queue< pair<ll,int> > Q;
inline void Dijkstra()
{
	for(int i=2;i<=n;i++) Dist[i]=INF;
	Q.push(make_pair(0,1));
	ll cost;
	for(int now,rear;!Q.empty();)
	{
		now=Q.top().second,Q.pop();
		if(V[now]) continue;
		//printf("%d\n",now);
		V[now]=1;
		for(int i=0;i<G[now].size();i++)
		{
			rear=G[now][i].nxt;
			
			if(LessThanSqrt(Dist[now]+1,G[now][i].d)) cost=floor(2*sqrt(G[now][i].d));
			else cost=(Dist[now]+1)+G[now][i].d/(Dist[now]+1);
			cost+=G[now][i].c-1;
			
			//printf("from %d to %d, c %d d %d, cost %lld\n",now,rear,G[now][i].c,G[now][i].d);
			
			if(Dist[rear]>cost) Dist[rear]=cost,Q.push(make_pair(-Dist[rear],rear));
		}
	}
}

int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int a,b,c,d;m--;)
	{
		scanf("%d %d %d %d",&a,&b,&c,&d);
		G[a].push_back(DE{b,c,d});
		G[b].push_back(DE{a,c,d});
	}
	Dijkstra();
	if(Dist[n]==INF) printf("-1\n");
	else printf("%lld\n",Dist[n]);
	return 0;
}
