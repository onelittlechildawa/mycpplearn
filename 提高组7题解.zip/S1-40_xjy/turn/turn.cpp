#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef pair<int,int> pr;

const int MAXN=1e3,MAXM=2e5;

struct DE
{
	int x,y;
	inline void Scan() {scanf("%d %d",&x,&y);}
}E[MAXM+5];

int n,m;
vector<pr> nxt[MAXN+5];
bool Reac[MAXN+5][MAXN+5];
vector<int> V[MAXN+5];
queue<int> Q;
bool Twin[MAXM+5];

void GetReac(int now,int S)
{
	if(Reac[S][now]) return;
	Reac[S][now]=1;
	for(int i=0;i<nxt[now].size();i++) GetReac(nxt[now][i].first,S);
}

int main()
{
	freopen("turn.in","r",stdin);
	freopen("turn.out","w",stdout);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=m;i++)
	{
		E[i].Scan();
		nxt[E[i].x].push_back(make_pair(E[i].y,i));
	}
	for(int i=1;i<=n;i++) GetReac(i,i);
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++) V[j].clear();
		for(int j=0;j<nxt[i].size();j++)
		{
			Q.push(nxt[i][j].first);
			V[nxt[i][j].first].push_back(nxt[i][j].second);
		}
		for(int now,rear;!Q.empty();)
		{
			now=Q.front(),Q.pop();
			for(int j=0;j<nxt[now].size();j++)
			{
				rear=nxt[now][j].first;
				if(V[rear].size()==2 || rear==i) continue;
				if(V[rear].size()==1)
				{
					if(V[now].size()==1)
					{
						if(V[now][0]==V[rear][0]) continue;
						Q.push(rear);
						V[rear].push_back(V[now][0]);
					}
					else
					{
						if(V[now][0]==V[rear][0]) V[rear].push_back(V[now][1]);
						else V[rear].push_back(V[now][0]);
						Q.push(rear);
					}
				}
				else Q.push(rear),V[rear]=V[now];
			}
		}
		for(int j=0;j<nxt[i].size();j++)
			Twin[nxt[i][j].second]=(V[nxt[i][j].first].size()==2);
	}
	for(int i=1;i<=m;i++)
		if(Reac[E[i].y][E[i].x]^Twin[i]) printf("diff\n");
		else printf("same\n");
	return 0;
}
