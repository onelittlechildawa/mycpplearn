#include<bits/stdc++.h>
#define MAXN 100005
using namespace std;
typedef long long ll;
ll m,n;
ll a[MAXN],b[MAXN],c[MAXN],d[MAXN];
ll dis[MAXN];
bool vst[MAXN];
struct Node{
	ll id;
	ll dist;
};

const bool &operator <(const Node&a,const Node &b)
{
		return a.dist>b.dist;
}
struct Edge{
	ll to,c,d;
};
vector<Edge> E[MAXN];
priority_queue<Node> q;
ll division(ll di)
{
	ll ans=(ll)sqrt(di);
	while(di/(ans+1)<di/(ans+2))++ans;
	return ans; 
}
int main()
{
	freopen("road.in","r",stdin);
	freopen("road.out","w",stdout);
	cin>>n>>m;
	for(ll i=1;i<=m;++i)
	{
		cin>>a[i]>>b[i]>>c[i]>>d[i];
		E[a[i]].push_back((Edge){b[i],c[i],d[i]});
		E[b[i]].push_back((Edge){a[i],c[i],d[i]});
	}
	dis[1]=0;
	q.push((Node){1,0});
	while(!q.empty())
	{
		Node now=q.top();
//		cout<<now.id<<' '<<now.dist<<endl;
		q.pop();
		if(vst[now.id])
			continue;
		vst[now.id]=1;
		dis[now.id]=now.dist;
		for(ll i=0;i<E[now.id].size();++i)
		{
			if(vst[E[now.id][i].to])continue;
			ll div=division(E[now.id][i].d);
			if(dis[now.id]<=div)
			{
				q.push((Node){E[now.id][i].to,div+E[now.id][i].c+E[now.id][i].d/(div+1)});
			}
			else
			{
				q.push((Node){E[now.id][i].to,dis[now.id]+E[now.id][i].c+E[now.id][i].d/(now.dist+1)});
			}
		}
		
	}
	if(!vst[n])cout<<-1;
	else cout<<dis[n];
	return 0;
}
